import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { getDatabase, connectDatabaseEmulator, goOffline, ref, get, set } from 'firebase/database';

test('Email/Password login returns the allowlisted UID and permits a real SDK database write', { timeout: 20000 }, async () => {
  const email = `integration-${Date.now()}@example.test`;
  const password = 'Local-fixture-only-2026!';
  const response = await fetch('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signUp?key=demo-key', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, returnSecureToken: true })
  });
  assert.equal(response.status, 200);
  const account = await response.json();
  const fixture = JSON.parse(await readFile('database.seed.json', 'utf8'));
  const permission = await fetch('http://127.0.0.1:9000/.json?ns=demo-dynamic-landing-default-rtdb', {
    method: 'PUT', headers: { Authorization: 'Bearer owner', 'Content-Type': 'application/json' }, body: JSON.stringify({ admins: { [account.localId]: true }, site: fixture.site, images: fixture.images })
  });
  assert.equal(permission.status, 200);
  const app = initializeApp({ apiKey: 'demo-key', projectId: 'demo-dynamic-landing', databaseURL: 'https://demo-dynamic-landing-default-rtdb.firebaseio.com' }, 'email-password-integration');
  let db;
  try {
    const auth = getAuth(app); connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
    db = getDatabase(app); connectDatabaseEmulator(db, '127.0.0.1', 9000);
    await assert.rejects(() => signInWithEmailAndPassword(auth, email, 'Incorrect-local-password'));
    const signedIn = await signInWithEmailAndPassword(auth, email, password);
    assert.equal(signedIn.user.uid, account.localId);
    assert.equal((await get(ref(db, `admins/${account.localId}`))).val(), true);
    await set(ref(db, 'site/content/brandTitle'), 'Password authentication verified');
    assert.equal((await get(ref(db, 'site/content/brandTitle'))).val(), 'Password authentication verified');
    await signOut(auth);
    await assert.rejects(() => set(ref(db, 'site/content/brandTitle'), 'Unauthorized'));
  } finally { if (db) goOffline(db); await deleteApp(app); }
});
