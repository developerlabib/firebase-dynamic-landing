import { before, after, test } from 'node:test';
import { readFile } from 'node:fs/promises';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { ref, get, set, update } from 'firebase/database';

let env;
let seed;
before(async () => {
  seed = JSON.parse(await readFile('database.seed.json', 'utf8'));
  env = await initializeTestEnvironment({ projectId: 'demo-dynamic-landing', database: { host: '127.0.0.1', port: 9000, rules: await readFile('database.rules.json', 'utf8') } });
  await env.withSecurityRulesDisabled(async context => { await set(ref(context.database()), { admins: { 'test-admin': true }, site: seed.site, images: seed.images }); });
});
after(async () => { if (env) await env.cleanup(); });
test('public visitors can read content and one image, but cannot list all images or write', async () => {
  const db = env.unauthenticatedContext().database();
  await assertSucceeds(get(ref(db, 'site')));
  await assertSucceeds(get(ref(db, 'images/photo-1')));
  await assertFails(get(ref(db, 'images')));
  await assertFails(get(ref(db, 'admins')));
  await assertFails(set(ref(db, 'site/content/brandTitle'), 'Attack'));
  await assertFails(set(ref(db, 'images/attack'), { data: 'bad' }));
});
test('a signed-in account without the administrator UID cannot change data or promote itself', async () => {
  const db = env.authenticatedContext('ordinary-user').database();
  await assertSucceeds(get(ref(db, 'admins/ordinary-user')));
  await assertFails(set(ref(db, 'site/content/brandTitle'), 'Attack'));
  await assertFails(set(ref(db, 'admins/ordinary-user'), true));
  await assertFails(get(ref(db, 'admins/test-admin')));
});
test('administrator can manage profiles, content and compressed images', async () => {
  const db = env.authenticatedContext('test-admin').database();
  await assertSucceeds(set(ref(db, 'site/content/brandTitle'), 'Updated brand'));
  await assertSucceeds(set(ref(db, 'site/profiles/new-profile'), { ...seed.site.profiles['profile-1'], name: 'New Name' }));
  await assertSucceeds(set(ref(db, 'site/profiles/new-profile/active'), false));
  await assertSucceeds(set(ref(db, 'site/profiles/new-profile'), null));
  await assertSucceeds(update(ref(db), { 'images/test-image': seed.images['photo-1'], 'site/imageMeta/test-image': seed.site.imageMeta['photo-1'] }));
  await assertSucceeds(get(ref(db, 'images')));
  await assertFails(set(ref(db, 'admins/other-admin'), true));
});
test('rules reject invalid profile ages, missing names, script URLs and unknown schema fields', async () => {
  const db = env.authenticatedContext('test-admin').database();
  await assertFails(set(ref(db, 'site/profiles/profile-1/age'), 17));
  await assertFails(set(ref(db, 'site/profiles/profile-1/name'), null));
  await assertFails(set(ref(db, 'site/buttons/cta/url'), 'javascript:alert(1)'));
  await assertFails(set(ref(db, 'site/unknown'), 'oops'));
  await assertFails(set(ref(db, 'site/settings/onlineIntervalMs'), 100));
  await assertFails(set(ref(db, 'site/conversations/conversation-1/options/8'), 'Too many'));
});
test('rules reject oversized images and unrecognized image data', async () => {
  const db = env.authenticatedContext('test-admin').database();
  await assertFails(set(ref(db, 'images/invalid'), { data: 'data:image/svg+xml;base64,PHN2Zz4=' }));
  await assertFails(set(ref(db, 'images/huge'), { data: 'data:image/jpeg;base64,' + 'A'.repeat(170000) }));
});
