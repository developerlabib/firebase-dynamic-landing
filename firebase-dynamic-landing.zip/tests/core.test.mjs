import test from 'node:test';
import assert from 'node:assert/strict';
import { chooseProfile, chooseConversation, redirectUrl, resolveTokens, safeUrl, readSession, ConversationFlow, validateProfile, validateConversation } from '../public/assets/core.js';

const profiles = { a: { active: true }, b: { active: false }, c: { active: true } };
test('only active profiles are selected; the session assignment survives metadata changes', () => {
  assert.equal(chooseProfile(profiles, null, () => 0), 'a');
  assert.equal(chooseProfile(profiles, null, () => .999), 'c');
  assert.equal(chooseProfile(profiles, 'a', () => .99), 'a');
  assert.equal(chooseProfile(profiles, 'b', () => .99), 'c');
  assert.equal(chooseProfile({ a: { active: false } }, 'a'), null);
  assert.equal(chooseProfile({}, 'a'), null);
});
test('an inactive or deleted assignment is replaced; inactive conversation overrides are ignored', () => {
  const conversations = { one: { active: false }, two: { active: true }, three: { active: true } };
  assert.equal(chooseConversation(conversations, { conversationId: 'one' }, 'two'), 'two');
  assert.equal(chooseConversation(conversations, { conversationId: 'three' }, 'two'), 'three');
  assert.equal(chooseConversation(conversations, {}, 'two'), 'two');
  assert.equal(chooseConversation({}, {}, 'two'), null);
});
test('URL forwarding preserves destination query, repeated visitor parameters and fragments', () => {
  const url = new URL(redirectUrl('https://example.com/landing?partner=10#chat', '?utm_source=mail&tag=a&tag=b', true));
  assert.equal(url.searchParams.get('partner'), '10');
  assert.deepEqual(url.searchParams.getAll('tag'), ['a', 'b']);
  assert.equal(url.hash, '#chat');
  assert.equal(redirectUrl('https://example.com/?x=1#hash', '?y=2', false), 'https://example.com/?x=1#hash');
  for (const url of ['javascript:alert(1)', 'data:text/html,hi', '//example.com', 'https://u:p@example.com']) assert.throws(() => safeUrl(url));
});
test('tokens are plain strings and malformed session data falls back safely', () => {
  assert.equal(resolveTokens('Hi {name} in {city} from {brand}', { name: '<script>', city: 'Dhaka', brand: 'Website' }), 'Hi <script> in Dhaka from Website');
  assert.deepEqual(readSession({ getItem() { throw new Error(); } }, 'x'), {});
  assert.deepEqual(readSession({ getItem() { return '{invalid'; } }, 'x'), {});
});
test('conversation messages appear in order and rapid repeated clicks produce only one reply', async () => {
  const messages = [], options = [], typing = [];
  const conversation = { initial: 'hello', options: ['A', 'B'], followUps: ['follow'], closing: 'close' };
  const flow = new ConversationFlow({ wait: () => Promise.resolve(), message: (kind, text) => messages.push([kind, text]), options: value => options.push(value), typing: value => typing.push(value), timing: () => ({}), conversation: () => conversation, random: () => 0 });
  await flow.start();
  const first = flow.reply('A');
  assert.equal(await flow.reply('B'), false);
  await first;
  assert.deepEqual(messages, [['initial', 'hello'], ['reply', 'A'], ['followUp', 'follow'], ['closing', 'close']]);
  assert.equal(flow.state, 'done');
  assert.equal(await flow.reply('A'), false);
  assert.equal(typing.at(-1), false);
  assert.deepEqual(options.at(-1), []);
});
test('cancelling a profile mid-sequence prevents old messages from appearing', async () => {
  const waits = [], messages = [];
  const flow = new ConversationFlow({ wait: () => new Promise(resolve => waits.push(resolve)), message: (...args) => messages.push(args), options() {}, typing() {}, timing: () => ({}), conversation: () => ({ initial: 'stale' }) });
  const running = flow.start(); flow.cancel(); waits.shift()(); await running;
  assert.deepEqual(messages, []);
});
test('profile and conversation validation catches unusable records', () => {
  assert.throws(() => validateProfile({ name: 'Name', age: 17, active: true, imageId: 'photo' }));
  assert.throws(() => validateProfile({ name: 'Name', age: 22, active: true, imageId: '' }));
  assert.throws(() => validateConversation({ title: 'Hi', initial: 'Hello', closing: 'Bye', options: [], followUps: ['Hi'] }));
  assert.equal(validateProfile({ name: 'Name', age: 22, active: true, imageId: 'photo' }).name, 'Name');
});
