# নতুন Firebase প্রোজেক্টে সেটআপ

এই ZIP নতুন প্রোজেক্টের জন্য। আপনার Firebase-এর তথ্য ম্যানুয়ালি বসাবেন। আগের ডিজাইন, লোডিং অ্যানিমেশন, প্রোফাইল ব্যাজ ও ভিডিও কলের সাইনআপ পপআপ দেওয়া আছে।

## ১. Firebase-এ যা তৈরি করবেন

1. একটি নতুন Firebase Project তৈরি করুন। Project settings থেকে Web App (`</>`) যোগ করুন।
2. Realtime Database তৈরি করুন, Locked mode বেছে নিন এবং database URL কপি করুন।
3. Authentication → Sign-in method থেকে Email/Password চালু করুন।
4. Authentication → Users → Add user দিয়ে নিজের অ্যাডমিন ইমেইল ও পাসওয়ার্ড দিন। তৈরি হওয়া ইউজারের UID কপি করুন।

## ২. শুধু এই ৩টি ফাইল এডিট করুন

| ফাইল | কী বসাবেন |
|---|---|
| `public/firebase-config.js` | Web App-এর `apiKey`, `authDomain`, `projectId`, `appId` এবং Realtime Database-এর `databaseURL` |
| `.firebaserc` | `REPLACE_PROJECT_ID`-এর জায়গায় নতুন প্রোজেক্টের Project ID |
| `database.seed.json` | `REPLACE_ADMIN_UID`-এর জায়গায় Authentication থেকে কপি করা নিজের UID |

`firebase-config.js`-এ প্রতিটি `REPLACE_...` লেখা নিজের তথ্য দিয়ে বদলান। উদ্ধৃতি চিহ্ন ঠিক রাখুন। Project ID দুই ফাইলে একই হবে।

`database.seed.json`-এর শুরুতে এই অংশটি আছে:

```json
"admins": {
  "REPLACE_ADMIN_UID": true
}
```

এখানে শুধু `REPLACE_ADMIN_UID` বদলাবেন; `true` যেমন আছে তেমন থাকবে। পুরো JSON ফাইলের বাকি অংশ রাখবেন।

`.firebaserc` দেখা না গেলে ফাইল ম্যানেজারে Show hidden files চালু করুন। অ্যাডমিনের ইমেইল বা পাসওয়ার্ড কোনো ফাইলে লিখবেন না।

## ৩. নতুন ডাটাবেজে ডাটা দিন

Realtime Database → Data খুলুন। ডাটাবেজের root বা একেবারে ওপরের স্তরের ⋮ মেনু থেকে Import JSON বেছে এডিট করা `database.seed.json` দিন।

এটি শুধু নতুন, খালি ডাটাবেজের জন্য। এতে প্রোফাইল, ছবি, কথোপকথন ও অ্যাডমিন অনুমতি একসঙ্গে যুক্ত হবে।

## ৪. ডিপ্লয় করুন

কম্পিউটারে Node.js 22 বা পরের সংস্করণ রাখুন। ZIP খুলে `firebase-dynamic-landing` ফোল্ডারে টার্মিনাল খুলে চালান:

```sh
npm ci
npx firebase login
npm run check -- --configured
npx firebase deploy --only database,hosting
```

`check` সফল হলে ডিপ্লয় কমান্ড দিন। এতে ওয়েবসাইটের সঙ্গে `database.rules.json`-এর রুলসও প্রকাশ হবে।

## ৫. সাইট ও অ্যাডমিন খুলুন

ডিপ্লয়ের শেষে দেখানো Hosting URL-এ সাইট খুলুন। ওই URL-এর শেষে `/admin.html` যোগ করলে অ্যাডমিন প্যানেল পাবেন। Authentication-এ তৈরি করা নিজের ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করুন।

Admin Panel → Buttons & Links থেকে নিজের সাইনআপ/CTA লিংক সেট করুন। ভিডিও আইকনের সাইনআপ বাটনও সেই লিংক ব্যবহার করবে। কোনো প্রোফাইলে আলাদা URL থাকলে সেটি অগ্রাধিকার পাবে।

পরেরবার শুধু HTML/CSS/JavaScript বদলালে ডিপ্লয়:

```sh
npx firebase deploy --only hosting
```
