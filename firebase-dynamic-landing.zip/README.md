# Firebase Dynamic Landing — New Project Edition

Start with **[SETUP-BN.md](SETUP-BN.md)** for short Bengali instructions. This is a separate starter for a new Firebase project. The previous project's app settings, Project ID and administrator UID have been replaced with placeholders.

## Manual setup

1. Create a Firebase project and register a Web App.
2. Create a Realtime Database in locked mode and copy its URL.
3. Enable Email/Password Authentication. Create an administrator user and copy the UID.
4. Edit `public/firebase-config.js` with your Web App settings and database URL.
5. Edit `.firebaserc` with the same Project ID.
6. Replace `REPLACE_ADMIN_UID` in `database.seed.json` with your administrator UID.
7. Import the edited `database.seed.json` at the root of the new, empty Realtime Database.
8. From this folder, with Node.js 22 or newer:

```sh
npm ci
npx firebase login
npm run check -- --configured
npx firebase deploy --only database,hosting
```

The deployment publishes both the database rules and Hosting files. Open the Hosting URL for the website, or append `/admin.html` to sign in to administration. In Buttons & Links, set your signup/CTA destination. Profile-specific URLs override the global destination.

The `--configured` check requires completed placeholders, an administrator UID and matching Project IDs. `npm run check` alone validates the starter before configuration. No build step is required. Never put an administrator password or service-account key in public files.

## Included interface

- Animated search screen: **Finding someone special in your area**.
- Green active dot above the profile photo border.
- Facebook-style blue badge with a white check.
- Video camera icon opening a signup prompt that shares the main CTA's destination and tracking settings.
- Synchronized age confirmation and the existing CTA enabled setting.
- Existing profiles, compressed photos, editable conversations and English Admin Panel.

The original conversation is scripted and the original online counter is simulated. The video icon provides a signup redirect; this landing page does not implement video streaming. The destination service controls registration and any video calling.

## Checks

```sh
npm run check
npm test
```

Optional rules/authentication emulator tests are available through `npm run test:rules` and `npm run test:firebase`; they require the developer dependencies and Java 21 or newer.

For later changes to Hosting files only, run `npx firebase deploy --only hosting`. Keep the initial root import for new, empty databases; an existing website's data should be managed through the Admin Panel.
