import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
admin="auth != null && root.child('admins').child(auth.uid).val() === true"
def text(n=2000,nonempty=False):
 return {'.validate':f"newData.isString() && newData.val().length <= {n}"+(" && newData.val().length > 0" if nonempty else '')}
def number(lo,hi,integer=True):
 return {'.validate':f"newData.isNumber() && newData.val() >= {lo} && newData.val() <= {hi}"+(" && newData.val() % 1 === 0" if integer else '')}
def record(required,children):
 return {'.validate':'newData.hasChildren('+json.dumps(required)+')',**children,'__revision':number(0,1000000000),'updatedAt':number(0,100000000000000),'updatedBy':text(128),'$other':{'.validate':False}}
content_keys=['pageTitle','metaDescription','brandTitle','onlineTemplate','locationPrefix','fallbackCity','chatPill','dateLabel','ageLabel','ageEmphasis','imageAlt','suggestedSuffix','unavailableText','connectionText']
content=record(content_keys,{k:text(2000,k in ['pageTitle','brandTitle','fallbackCity','unavailableText']) for k in content_keys})
booleans=['showBrand','showProfile','showOnlineCounter','showDate','showChat','showSuggested','showCta','showAgeCheck','showVerified','showAvatarStatus','enableGeolocation','simulateOnlineCounter']
timings=['initialPauseMs','initialTypingMs','replyPauseMs','replyTypingMs','closingPauseMs','closingTypingMs']
settings_children={k:{'.validate':'newData.isBoolean()'} for k in booleans}
settings_children.update({k:number(0,30000) for k in timings})
settings_children.update({'onlineBase':number(0,100000000),'onlineIntervalMs':number(1000,60000)})
settings=record(list(settings_children),settings_children)
url="newData.isString() && newData.val().length <= 2000 && newData.val().matches(/^https?:\\/\\/.+/)"
profile=record(['name','age','active','imageId','order'],{
 'name':text(100,True),'age':number(18,120),'active':{'.validate':'newData.isBoolean()'},'imageId':text(128,True),
 'location':text(100),'bio':text(),'extra':text(),'conversationId':text(128),'url':{'.validate':"newData.val() === '' || ("+url+")"},'buttonLabel':text(),'order':number(-100000,100000,False)})
conversation=record(['title','initial','options','followUps','closing','active','order'],{
 'title':text(150,True),'initial':text(2000,True),'closing':text(2000,True),'active':{'.validate':'newData.isBoolean()'},'order':number(-100000,100000,False),
 'options':{'.validate':"newData.hasChild('0')",'$i':{'.validate':"$i.matches(/^[0-7]$/) && newData.isString() && newData.val().length > 0 && newData.val().length <= 2000"}},
 'followUps':{'.validate':"newData.hasChild('0')",'$i':{'.validate':"$i.matches(/^([0-9]|1[01])$/) && newData.isString() && newData.val().length > 0 && newData.val().length <= 2000"}}})
meta=record(['name','mime','bytes','width','height','createdAt'],{'name':text(150,True),'mime':{'.validate':"newData.val() === 'image/jpeg' || newData.val() === 'image/png' || newData.val() === 'image/webp'"},'bytes':number(1,122880),'width':number(1,640),'height':number(1,640),'createdAt':number(0,100000000000000)})
button=record(['label','url','enabled','preserveQuery'],{'label':text(2000,True),'url':{'.validate':url},'enabled':{'.validate':'newData.isBoolean()'},'preserveQuery':{'.validate':'newData.isBoolean()'}})
rules={'.read':False,'.write':False,
 'admins':{'$uid':{'.read':'auth != null && auth.uid === $uid','.write':False}},
 'site':{'.read':True,'.write':admin,'.validate':"newData.hasChildren(['schemaVersion','content','settings','buttons']) && newData.child('schemaVersion').val() === 1",'schemaVersion':{'.validate':'newData.val() === 1'},'content':content,'settings':settings,'buttons':{'.validate':"newData.hasChild('cta')",'cta':button,'$other':{'.validate':False}},'profiles':{'$id':profile},'conversations':{'$id':conversation},'imageMeta':{'$id':meta},'$other':{'.validate':False}},
 'images':{'.read':admin,'.write':admin,'$id':{'.read':True,'.validate':"newData.hasChildren(['data'])",'data':{'.validate':"newData.isString() && newData.val().length <= 170000 && newData.val().matches(/^data:image\\/(jpeg|png|webp);base64,[A-Za-z0-9+\\/=]+$/)"},'$other':{'.validate':False}}}}
(root/'database.rules.json').write_text(json.dumps({'rules':rules},indent=2)+'\n')
