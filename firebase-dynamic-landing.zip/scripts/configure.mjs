import { readFile, writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
const prompt = createInterface({ input: stdin, output: stdout });
try {
  console.log('Firebase one-time configuration. Copy values from Project settings > Your apps.');
  const config = {};
  for (const key of ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'appId']) {
    config[key] = (await prompt.question(`${key}: `)).trim();
    if (!config[key] || config[key].includes('REPLACE_')) throw new Error(`${key} is required.`);
  }
  const url = new URL(config.databaseURL);
  if (url.protocol !== 'https:' || !/(\.firebaseio\.com|\.firebasedatabase\.app)$/.test(url.hostname)) throw new Error('Use the HTTPS Realtime Database URL from Firebase Console.');
  const uid = (await prompt.question('Administrator UID (Authentication > Users): ')).trim();
  if (!uid || uid.length > 128 || /[.#$\[\]/\s]/.test(uid)) throw new Error('Copy a valid administrator UID.');
  await writeFile('public/firebase-config.js', `// Public Firebase Web App identifiers. Never place passwords or private keys here.\nexport const firebaseConfig = ${JSON.stringify(config, null, 2)};\nexport const localEmulators = null;\n`);
  await writeFile('.firebaserc', JSON.stringify({ projects: { default: config.projectId } }, null, 2) + '\n');
  const seed = JSON.parse(await readFile('database.seed.json', 'utf8'));
  seed.admins = { [uid]: true };
  await writeFile('database.seed.json', JSON.stringify(seed, null, 2) + '\n');
  console.log('Saved firebase-config.js, .firebaserc and database.seed.json.');
  console.log('Next: publish database.rules.json; import database.seed.json at the ROOT of your EMPTY Realtime Database. Then deploy Hosting.');
  console.log('For an existing database, add /admins/<UID>: true manually, then initialize from the Admin Panel; do not import the seed over existing data.');
} catch (error) { console.error(error.message); process.exitCode = 1; }
finally { prompt.close(); }
