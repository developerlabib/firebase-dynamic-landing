import { readFile, readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { validateProfile, validateConversation } from '../public/assets/core.js';
const files = await readdir('public/assets');
for (const file of files.filter(x => x.endsWith('.js'))) {
  const result = spawnSync(process.execPath, ['--check', `public/assets/${file}`], { encoding: 'utf8' });
  if (result.status !== 0) throw new Error(result.stderr);
}
for (const file of ['firebase.json', 'database.rules.json', 'database.seed.json', 'public/initial-content.json']) JSON.parse(await readFile(file, 'utf8'));
const seed = JSON.parse(await readFile('database.seed.json', 'utf8'));
for (const p of Object.values(seed.site.profiles)) validateProfile(p);
for (const c of Object.values(seed.site.conversations)) validateConversation(c);
for (const [id, m] of Object.entries(seed.site.imageMeta)) {
  if (!seed.images[id]?.data || m.bytes > 122880 || m.width > 640 || m.height > 640) throw new Error(`Invalid seed image ${id}`);
}
if (process.argv.includes('--configured')) {
  const config = await readFile('public/firebase-config.js', 'utf8');
  const rc = await readFile('.firebaserc', 'utf8');
  if (config.includes('REPLACE_') || rc.includes('REPLACE_')) throw new Error('Complete public/firebase-config.js and .firebaserc before deployment. See SETUP-BN.md; manual editing is supported.');
  if (!Object.entries(seed.admins || {}).some(([uid, enabled]) => enabled === true && uid && !uid.includes('REPLACE_'))) throw new Error('Replace REPLACE_ADMIN_UID in database.seed.json with your Authentication user UID.');
  const { firebaseConfig } = await import('../public/firebase-config.js');
  if (firebaseConfig.projectId !== JSON.parse(rc).projects?.default) throw new Error('The Project ID must match in public/firebase-config.js and .firebaserc.');
  if (!/export const localEmulators = null/.test(config)) throw new Error('Disable local emulators before deployment.');
}
console.log('JavaScript syntax, JSON configuration and original seed content are valid.');
