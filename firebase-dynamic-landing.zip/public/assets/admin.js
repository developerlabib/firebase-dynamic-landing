import { entries, validateProfile, validateConversation, safeUrl, MAX_DATA_URL_LENGTH } from './core.js';
import { compressImage } from './images.js';

const $ = id => document.getElementById(id);
const state = { site: null, user: null, connected: false, dirty: false, busy: false, page: 'dashboard', imageCache: new Map() };
let db, database, auth, authApi, siteUnsubscribe, connectionUnsubscribe, imageObserver, toastTimer, editorSubmit, authGeneration = 0, editorGeneration = 0;
const titles = {
  dashboard: ['Overview', 'A clear view of your website, all in one place.'],
  profiles: ['Profiles', 'Manage every profile independently. Only active profiles are assigned to visitors.'],
  images: ['Image Management', 'Upload, compress and reuse photos without Firebase Storage.'],
  content: ['Website Content', 'Update the text visitors see, without editing HTML.'],
  conversations: ['Conversations', 'Control opening messages, suggested replies and the final invitation.'],
  buttons: ['Buttons & Links', 'Manage destination links, button labels and tracking parameters.'],
  settings: ['Sections & Behavior', 'Control visibility, location detection and conversation timing.'],
  backup: ['Backup & Setup', 'Initialize your website, export a backup or restore saved content.']
};
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function button(text, action, kind = 'secondary') {
  const node = el('button', kind, text); node.type = 'button'; node.onclick = action; return node;
}
function notify(message, error = false) {
  clearTimeout(toastTimer); $('toast').textContent = message; $('toast').className = error ? 'error-toast' : ''; $('toast').hidden = false;
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, error ? 9000 : 4500);
}
function errorText(error) {
  if (error.code?.includes('permission-denied') || error.code === 'PERMISSION_DENIED') return 'Permission denied. Check that your UID is enabled under /admins and that the database rules are published.';
  if (error.code?.startsWith('auth/')) {
    if (error.code === 'auth/network-request-failed') return 'Cannot reach Firebase. Check your internet connection.';
    if (error.code === 'auth/too-many-requests') return 'Too many attempts. Please wait and try again.';
    if (error.code === 'auth/operation-not-allowed') return 'Enable Email/Password in Firebase Authentication first.';
    if (error.code === 'auth/invalid-api-key') return 'The Firebase API key is invalid. Check firebase-config.js.';
    return 'Sign-in failed. Check your email, password and Firebase Authentication setup.';
  }
  return error.message || 'The operation failed. Please try again.';
}
function ensureOnline() {
  if (!state.user) throw new Error('Please sign in again.');
  if (!state.connected || !navigator.onLine) throw new Error('You are offline. Reconnect before saving changes.');
}
function sorted(value) { return entries(value).sort((a, b) => (a[1].order || 0) - (b[1].order || 0) || a[0].localeCompare(b[0])); }
function revision(item) { return item?.__revision || 0; }
async function commit(path, value, expectedRevision) {
  ensureOnline();
  const reference = database.ref(db, path);
  const current = (await database.get(reference)).val();
  if (revision(current) !== expectedRevision) throw new Error('This item changed in another session. Close the editor, reopen it and review the latest version.');
  const result = await database.runTransaction(reference, currentValue => {
    if (revision(currentValue) !== expectedRevision) return;
    if (value === null) return null;
    return { ...value, __revision: expectedRevision + 1, updatedAt: Date.now(), updatedBy: state.user.uid };
  }, { applyLocally: false });
  if (!result.committed) throw new Error('Another administrator changed this item. Reopen the editor and try again.');
}
function stat(label, number, note) {
  const card = el('div', 'card metric-card'); card.append(el('p', 'metric-label', label), el('div', 'metric', number), el('p', 'metric-note', note)); return card;
}
function note(text, warn = false) { return el('div', `note${warn ? ' warn' : ''}`, text); }
function empty(text) { return el('div', 'empty', text); }
function closeEditor() {
  if (state.busy) return;
  if (state.dirty && !confirm('Discard your unsaved changes?')) return;
  state.dirty = false; $('editor').close();
  editorGeneration++;
}
function field(labelText, name, value = '', type = 'text', hint = '', options = null) {
  const label = el('label', type === 'textarea' || type === 'file' ? 'full' : '');
  let input;
  if (type === 'checkbox') {
    label.className = 'check-label full'; input = el('input'); input.type = 'checkbox'; input.checked = Boolean(value);
    const description = el('span', '', labelText); if (hint) description.append(el('small', '', hint)); label.append(input, description);
  } else {
    label.append(document.createTextNode(labelText));
    if (type === 'select') {
      input = el('select'); (options || []).forEach(([key, text]) => { const option = el('option', '', text); option.value = key; input.append(option); }); input.value = value || '';
    } else if (type === 'textarea') { input = el('textarea'); input.value = value ?? ''; }
    else { input = el('input'); input.type = type; if (type !== 'file') input.value = value ?? ''; }
    label.append(input); if (hint) label.append(el('small', '', hint));
  }
  input.name = name;
  if (['text', 'textarea'].includes(type)) input.maxLength = name === 'options' || name === 'followUps' ? 24000 : 2000;
  $('editor-fields').append(label);
  return input;
}
function divider(title, description = '') {
  const node = el('div', 'form-divider'); node.append(el('h3', '', title)); if (description) node.append(el('p', 'muted', description)); $('editor-fields').append(node);
}
function openEditor(title, build, submit) {
  if ($('editor').open && state.dirty && !confirm('Discard your unsaved changes?')) return;
  state.dirty = false; state.busy = false; $('editor-title').textContent = title;
  editorGeneration++;
  $('editor-fields').replaceChildren(); $('editor-error').textContent = ''; $('save-editor').disabled = false;
  $('save-editor').textContent = 'Save changes'; editorSubmit = submit; build();
  if (!$('editor').open) $('editor').showModal();
}
function valuesFromForm() {
  const values = {};
  $('editor-form').querySelectorAll('[name]').forEach(input => { values[input.name] = input.type === 'checkbox' ? input.checked : input.type === 'number' ? Number(input.value) : input.value; });
  return values;
}
function initImages() {
  imageObserver?.disconnect();
  imageObserver = new IntersectionObserver(changes => {
    for (const change of changes) if (change.isIntersecting) {
      const image = change.target; imageObserver.unobserve(image);
      void getImage(image.dataset.imageId).then(data => { if (image.isConnected) image.src = data || './assets/avatar-placeholder.svg'; }).catch(() => {});
    }
  }, { rootMargin: '180px' });
  document.querySelectorAll('img[data-image-id]').forEach(image => imageObserver.observe(image));
}
async function getImage(id) {
  if (!id) return '';
  if (state.imageCache.has(id)) return state.imageCache.get(id);
  const value = (await database.get(database.ref(db, `images/${id}/data`))).val();
  if (typeof value !== 'string' || !/^data:image\/(jpeg|png|webp);base64,/.test(value)) return '';
  if (state.imageCache.size >= 12) state.imageCache.delete(state.imageCache.keys().next().value);
  state.imageCache.set(id, value); return value;
}
function thumb(id, name) {
  const img = el('img', 'profile-cover'); img.src = './assets/avatar-placeholder.svg'; img.alt = name || 'Profile image'; img.loading = 'lazy'; img.decoding = 'async'; img.dataset.imageId = id || ''; return img;
}
function overview() {
  const s = state.site, profiles = entries(s.profiles), active = profiles.filter(([, p]) => p.active);
  const cards = el('div', 'cards');
  cards.append(stat('Total profiles', profiles.length, `${active.length} active · ${profiles.length - active.length} inactive`), stat('Image library', entries(s.imageMeta).length, 'Compressed and stored in your database'), stat('Conversations', entries(s.conversations).length, 'Opening, suggested replies and follow-ups'));
  $('page-content').append(cards);
  if (!active.length) $('page-content').append(note('No active profiles. Visitors will see the unavailable message until you activate a profile.', true));
  const split = el('div', 'split'), list = el('section', 'card'), quick = el('section', 'card');
  list.append(el('h3', '', 'Your profiles'), el('p', 'muted', 'Independent settings for every visitor profile.'));
  sorted(s.profiles).slice(0, 6).forEach(([id, profile]) => {
    const row = el('div', 'list-row'), text = el('div'); text.append(el('p', '', `${profile.name}, ${profile.age}`), el('small', '', profile.location || 'Visitor location'));
    row.append(text, el('span', `badge ${profile.active ? 'good' : 'off'}`, profile.active ? 'Active' : 'Inactive'), button('Edit', () => editProfile(id))); list.append(row);
  });
  quick.append(el('h3', '', 'Quick actions'), el('p', 'muted', 'Changes appear on the public website automatically.'));
  const actions = el('div', 'action-stack'); actions.append(button('+ Add a profile', () => editProfile(), 'primary'), button('Upload an image', uploadImage), button('Edit website text', () => { location.hash = '#content'; }), button('Create a backup', () => void backup())); quick.append(actions);
  quick.append(el('p', 'small-note', 'Visitors receive one active profile per browser tab session. Inactive or deleted profiles are replaced automatically.'));
  split.append(list, quick); $('page-content').append(split);
}
function profilesPage() {
  $('page-actions').append(button('+ Add profile', () => editProfile(), 'primary'));
  const toolbar = el('div', 'toolbar'), searchLabel = el('label', 'search-label'), search = el('input'); search.placeholder = 'Search profiles...'; search.type = 'search'; search.setAttribute('aria-label', 'Search profiles'); searchLabel.append(search);
  const select = el('select'); select.setAttribute('aria-label', 'Filter profile status');
  for (const value of ['All profiles', 'Active only', 'Inactive only']) { const option = el('option', '', value); select.append(option); }
  const filter = el('div', 'filter'); filter.append(select); toolbar.append(searchLabel, filter); $('page-content').append(toolbar);
  const grid = el('div', 'profile-grid'); $('page-content').append(grid);
  const draw = () => {
    grid.replaceChildren();
    sorted(state.site.profiles).filter(([, p]) => p.name.toLowerCase().includes(search.value.toLowerCase()) && (select.selectedIndex === 0 || p.active === (select.selectedIndex === 1))).forEach(([id, p]) => {
      const card = el('article', 'card profile-card'), body = el('div', 'profile-body'), title = el('div', 'profile-name');
      title.append(el('h3', '', `${p.name}, ${p.age}`), el('span', `badge ${p.active ? 'good' : 'off'}`, p.active ? 'Active' : 'Inactive'));
      const actions = el('div', 'row-actions'); actions.append(button('Edit', () => editProfile(id)), button(p.active ? 'Deactivate' : 'Activate', () => void toggleProfile(id)), button('Delete', () => void deleteProfile(id), 'danger'));
      body.append(title, el('p', 'profile-detail', p.bio || p.location || 'Uses the visitor location'), actions); card.append(thumb(p.imageId, p.name), body); grid.append(card);
    });
    if (!grid.children.length) grid.append(empty('No profiles match. Add a profile or change your search.'));
    initImages();
  };
  search.oninput = draw; select.onchange = draw; draw();
}
function editProfile(id) {
  const p = id ? state.site.profiles?.[id] : { name: '', age: 23, active: true, imageId: '', location: '', bio: '', extra: '', conversationId: '', url: '', buttonLabel: '', order: entries(state.site.profiles).length + 1 };
  if (!p) return;
  const expected = revision(p);
  openEditor(id ? `Edit ${p.name}` : 'Add profile', () => {
    const name = field('Profile name', 'name', p.name); name.required = true; name.maxLength = 100;
    const age = field('Age', 'age', p.age, 'number'); age.min = 18; age.max = 120; age.required = true; age.step = 1;
    const image = field('Profile picture', 'imageId', p.imageId, 'select', 'Upload photos in Image Management first.', [['', 'Choose an image'], ...entries(state.site.imageMeta).map(([key, m]) => [key, m.name])]); image.required = true;
    field('List order', 'order', p.order || 0, 'number');
    field('Location override', 'location', p.location, 'text', 'Leave blank to use the visitor city.').maxLength = 100;
    field('Conversation', 'conversationId', p.conversationId, 'select', 'Use an active conversation, or let the website choose randomly.', [['', 'Random active conversation'], ...sorted(state.site.conversations).map(([key, c]) => [key, `${c.title}${c.active ? '' : ' (inactive)'}`])]);
    field('Profile description', 'bio', p.bio, 'textarea', 'Available in messages with {bio}.');
    field('Additional profile information', 'extra', p.extra, 'textarea', 'Available in messages with {extra}.');
    field('Button label override', 'buttonLabel', p.buttonLabel, 'text', 'Leave blank to use the global button label.');
    field('Destination URL override', 'url', p.url, 'url', 'Leave blank to use the global destination URL.');
    field('Active profile', 'active', p.active, 'checkbox', 'Include this profile in random visitor assignment.');
  }, async values => {
    values.name = values.name.trim(); values.url = safeUrl(values.url, { allowEmpty: true }); validateProfile(values);
    if (!state.site.imageMeta?.[values.imageId]) throw new Error('The selected image was deleted. Choose another image.');
    if (values.conversationId && !state.site.conversations?.[values.conversationId]?.active) throw new Error('Select an active conversation or use random assignment.');
    if (!Number.isFinite(values.order) || Math.abs(values.order) > 100000) throw new Error('List order must be between -100000 and 100000.');
    const key = id || database.push(database.ref(db, 'site/profiles')).key;
    await commit(`site/profiles/${key}`, values, expected);
  });
}
async function toggleProfile(id) {
  const p = state.site.profiles[id];
  try { await commit(`site/profiles/${id}`, { ...p, active: !p.active }, revision(p)); notify(p.active ? 'Profile deactivated.' : 'Profile activated.'); }
  catch (error) { notify(errorText(error), true); }
}
async function deleteProfile(id) {
  const p = state.site.profiles[id];
  if (!confirm(`Delete ${p.name}? Visitors assigned to this profile will receive another active profile. Its image will remain in Image Management.`)) return;
  try { await commit(`site/profiles/${id}`, null, revision(p)); notify('Profile deleted.'); } catch (error) { notify(errorText(error), true); }
}
function imagesPage() {
  $('page-actions').append(button('+ Upload image', uploadImage, 'primary'));
  $('page-content').append(note('JPG, JPEG, PNG, WebP, GIF, AVIF and BMP are resized to a maximum of 640 pixels and compressed to 120 KB or less. Animated images use a still frame.'));
  const grid = el('div', 'image-grid');
  entries(state.site.imageMeta).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0)).forEach(([id, meta]) => {
    const card = el('article', 'card profile-card image-card'), body = el('div', 'profile-body'), actions = el('div', 'row-actions');
    const uses = entries(state.site.profiles).filter(([, p]) => p.imageId === id);
    actions.append(button('Rename', () => renameImage(id)), button('Delete', () => void deleteImage(id), 'danger'));
    body.append(el('div', 'image-name', meta.name), el('p', 'image-info', `${meta.width} × ${meta.height} · ${(meta.bytes / 1024).toFixed(1)} KB · ${uses.length} profile${uses.length === 1 ? '' : 's'}`), actions);
    card.append(thumb(id, meta.name), body); grid.append(card);
  });
  if (!grid.children.length) grid.append(empty('Your image library is empty. Upload your first image.'));
  $('page-content').append(grid); initImages();
}
function uploadImage() {
  let compressed = null, processing = false, uploadVersion = 0;
  openEditor('Upload image', () => {
    const name = field('Image name', 'name', '', 'text', 'A descriptive name makes the photo easy to find.'); name.required = true; name.maxLength = 150;
    const file = field('Choose image', 'file', '', 'file', 'Maximum original file size: 20 MB. Compression happens in your browser.'); file.accept = 'image/jpeg,image/png,image/webp,image/gif,image/avif,image/bmp'; file.required = true;
    const preview = el('img', 'image-preview full'); preview.hidden = true; preview.alt = 'Compressed image preview';
    const info = el('p', 'muted full'); $('editor-fields').append(preview, info);
    file.onchange = async () => {
      const version = ++uploadVersion, dialogVersion = editorGeneration;
      compressed = null; if (!file.files[0]) return;
      processing = true; info.textContent = 'Resizing and compressing...'; $('save-editor').disabled = true; $('editor-error').textContent = '';
      try {
        const result = await compressImage(file.files[0]);
        if (version !== uploadVersion || dialogVersion !== editorGeneration) return;
        compressed = result; preview.src = result.data; preview.hidden = false;
        info.textContent = `${result.width} × ${result.height} pixels · ${(result.bytes / 1024).toFixed(1)} KB · ${Math.max(0, Math.round((1 - result.bytes / file.files[0].size) * 100))}% smaller`;
        if (!name.value) name.value = file.files[0].name.replace(/\.[^.]+$/, '').slice(0, 150);
      } catch (error) { if (version === uploadVersion && dialogVersion === editorGeneration) { $('editor-error').textContent = errorText(error); info.textContent = ''; } }
      finally { if (version === uploadVersion && dialogVersion === editorGeneration) { processing = false; $('save-editor').disabled = false; } }
    };
  }, async values => {
    ensureOnline(); if (!compressed || processing) throw new Error('Choose an image and wait for compression to finish.');
    if (!values.name.trim()) throw new Error('Enter an image name.');
    const id = database.push(database.ref(db, 'images')).key;
    const { data, ...metadata } = compressed;
    await database.update(database.ref(db), { [`images/${id}`]: { data }, [`site/imageMeta/${id}`]: { ...metadata, name: values.name.trim(), createdAt: Date.now(), __revision: 1 } });
    state.imageCache.set(id, data);
  });
}
function renameImage(id) {
  const meta = state.site.imageMeta[id];
  openEditor('Rename image', () => { const input = field('Image name', 'name', meta.name); input.required = true; input.maxLength = 150; }, async values => {
    if (!values.name.trim()) throw new Error('Image name is required.');
    await commit(`site/imageMeta/${id}`, { ...meta, name: values.name.trim() }, revision(meta));
  });
}
async function deleteImage(id) {
  if (entries(state.site.profiles).some(([, p]) => p.imageId === id)) { notify('This image is used by a profile. Choose another profile picture before deleting it.', true); return; }
  if (!confirm('Delete this image permanently?')) return;
  try {
    ensureOnline();
    const current = (await database.get(database.ref(db, 'site/profiles'))).val();
    if (entries(current).some(([, p]) => p.imageId === id)) throw new Error('This image was assigned to a profile in another session. Refresh before deleting it.');
    await database.update(database.ref(db), { [`images/${id}`]: null, [`site/imageMeta/${id}`]: null }); state.imageCache.delete(id); notify('Image deleted.');
  } catch (error) { notify(errorText(error), true); }
}
const contentFields = {
  pageTitle: ['Browser page title', 'text'], metaDescription: ['Search description', 'textarea'], brandTitle: ['Brand name', 'text'],
  onlineTemplate: ['Online counter text', 'text', 'Use {count} and {city}. The original counter is simulated, not measured traffic.'],
  locationPrefix: ['Location prefix', 'text'], fallbackCity: ['Fallback location', 'text'], chatPill: ['Video call icon label', 'text'], dateLabel: ['Date divider label', 'text'],
  ageLabel: ['Age confirmation text', 'text'], ageEmphasis: ['Age confirmation bold text', 'text'], imageAlt: ['Profile image description', 'text'],
  suggestedSuffix: ['Suggested reply suffix', 'text'], unavailableText: ['No active profiles / conversations message', 'textarea'], connectionText: ['Loading message after content arrives', 'text']
};
function contentPage() {
  $('page-content').append(note('Text is saved as plain text. Tokens are replaced safely with the current profile and visitor details.'));
  const groups = el('div', 'field-groups');
  for (const [title, description, fields] of [
    ['Brand & page information', 'Browser title, description and brand name.', ['pageTitle', 'metaDescription', 'brandTitle']],
    ['Header & profile text', 'Counter, location, video call accessibility label and image description.', ['onlineTemplate', 'locationPrefix', 'fallbackCity', 'chatPill', 'imageAlt']],
    ['Conversation & confirmation labels', 'Day label, reply suffix and age confirmation wording.', ['dateLabel', 'suggestedSuffix', 'ageLabel', 'ageEmphasis']],
    ['Status messages', 'Loading and unavailable messages.', ['unavailableText', 'connectionText']]
  ]) {
    const card = el('section', 'card field-card'), text = el('div'); text.append(el('h3', '', title), el('p', 'muted', description));
    card.append(text, button('Edit text', () => editContent(title, fields))); groups.append(card);
  }
  $('page-content').append(groups);
  const tokens = el('section', 'card'); tokens.style.marginTop = '22px'; tokens.append(el('h3', '', 'Available text tokens'), el('p', 'token-list', '{name}  {age}  {city}  {location}  {brand}  {bio}  {extra}  {count}'), el('p', 'muted', 'Use these tokens in conversation text. {name} and {brand} also work in the profile image description.')); $('page-content').append(tokens);
}
function editContent(title, fields) {
  const original = { ...state.site.content };
  openEditor(title, () => {
    fields.forEach(key => { const [label, type, hint] = contentFields[key]; const input = field(label, key, original[key], type, hint); if (['pageTitle', 'brandTitle', 'fallbackCity', 'unavailableText'].includes(key)) input.required = true; });
  }, async values => { await commit('site/content', { ...original, ...values }, revision(original)); });
}
function conversationsPage() {
  $('page-actions').append(button('+ Add conversation', () => editConversation(), 'primary'));
  $('page-content').append(note('Sequence: opening message → visitor suggested reply → random follow-up → closing invitation. Each visitor keeps the selected variant during the session.'));
  const grid = el('div', 'field-groups');
  sorted(state.site.conversations).forEach(([id, c]) => {
    const card = el('article', 'card'), heading = el('div', 'profile-name'); heading.append(el('h3', '', c.title), el('span', `badge ${c.active ? 'good' : 'off'}`, c.active ? 'Active' : 'Inactive'));
    const actions = el('div', 'row-actions'); actions.append(button('Edit conversation', () => editConversation(id)), button('Delete', () => void deleteConversation(id), 'danger'));
    card.append(heading, el('p', 'muted', c.initial), el('p', 'small-note', `${(c.options || []).length} suggested replies · ${(c.followUps || []).length} follow-up variants`), actions); grid.append(card);
  });
  if (!grid.children.length) grid.append(empty('Add an active conversation to enable the chat flow.'));
  $('page-content').append(grid);
}
function editConversation(id) {
  const c = id ? state.site.conversations[id] : { title: '', initial: '', options: [''], followUps: [''], closing: '', active: true, order: entries(state.site.conversations).length + 1 };
  openEditor(id ? 'Edit conversation' : 'Add conversation', () => {
    const title = field('Internal title', 'title', c.title); title.required = true; title.maxLength = 150;
    field('List order', 'order', c.order || 0, 'number');
    field('Opening message', 'initial', c.initial, 'textarea', 'Supports {name}, {city}, {brand}, {bio}, {extra}, {age} and {location}.').required = true;
    field('Suggested replies', 'options', (c.options || []).join('\n'), 'textarea', 'One suggested reply per line. Use 1-8 lines.').required = true;
    field('Follow-up variants', 'followUps', (c.followUps || []).join('\n'), 'textarea', 'One message per line. One of these 1-12 messages is chosen after the visitor replies.').required = true;
    field('Closing invitation', 'closing', c.closing, 'textarea', 'Sent after the follow-up. {brand} is displayed in bold, as on the original page.').required = true;
    field('Active conversation', 'active', c.active, 'checkbox', 'Inactive conversations are excluded from random selection.');
  }, async values => {
    values.options = values.options.split('\n').map(x => x.trim()).filter(Boolean); values.followUps = values.followUps.split('\n').map(x => x.trim()).filter(Boolean);
    const result = validateConversation(values);
    if (!Number.isFinite(values.order) || Math.abs(values.order) > 100000) throw new Error('List order must be between -100000 and 100000.');
    const key = id || database.push(database.ref(db, 'site/conversations')).key;
    await commit(`site/conversations/${key}`, result, revision(c));
  });
}
async function deleteConversation(id) {
  if (entries(state.site.profiles).some(([, p]) => p.conversationId === id)) { notify('A profile uses this conversation. Set that profile to a different conversation or random assignment first.', true); return; }
  if (!confirm('Delete this conversation? Visitors using it will receive another active variant.')) return;
  try { await commit(`site/conversations/${id}`, null, revision(state.site.conversations[id])); notify('Conversation deleted.'); } catch (error) { notify(errorText(error), true); }
}
function buttonsPage() {
  const b = state.site.buttons.cta;
  const card = el('section', 'card'); card.append(el('h3', '', 'Main continue button'), el('p', 'muted', 'The original bottom call-to-action button.'), el('p', '', b.label), el('p', 'muted', b.url), el('p', 'small-note', `${b.enabled ? 'Enabled' : 'Disabled'} · ${b.preserveQuery ? 'Preserves visitor query parameters' : 'Does not forward query parameters'}`), button('Edit button & destination', editButton, 'primary')); $('page-content').append(card);
  $('page-content').append(note('Profile-specific labels and URLs can be set in Profiles → Edit. Blank profile overrides use the global values above.'));
}
function editButton() {
  const b = { ...state.site.buttons.cta };
  openEditor('Main continue button', () => {
    field('Button label', 'label', b.label).required = true;
    field('Destination URL', 'url', b.url, 'url', 'A complete HTTPS or HTTP URL. Existing destination parameters and #fragments are supported.').required = true;
    field('Enable button', 'enabled', b.enabled, 'checkbox');
    field('Forward visitor query parameters', 'preserveQuery', b.preserveQuery, 'checkbox', 'Keeps tracking values such as utm_source. Destination query values are retained.');
  }, async values => { values.url = safeUrl(values.url); await commit('site/buttons/cta', values, revision(b)); });
}
const visibilityFields = [
  ['showBrand', 'Brand header'], ['showProfile', 'Profile header'], ['showOnlineCounter', 'Online counter'], ['showVerified', 'Verified check mark'],
  ['showAvatarStatus', 'Avatar status dot'], ['showChat', 'Conversation messages'], ['showDate', 'Date divider'], ['showSuggested', 'Suggested reply buttons'],
  ['showCta', 'Bottom call-to-action section'], ['showAgeCheck', 'Age confirmation checkbox']
];
const timingFields = [['initialPauseMs', 'Opening delay'], ['initialTypingMs', 'Opening typing duration'], ['replyPauseMs', 'Follow-up delay'], ['replyTypingMs', 'Follow-up typing duration'], ['closingPauseMs', 'Closing delay'], ['closingTypingMs', 'Closing typing duration']];
function settingsPage() {
  const groups = el('div', 'field-groups');
  for (const [title, description, mode] of [
    ['Section visibility', 'Enable or hide the sections already present on your landing page.', 'visibility'],
    ['Location & online counter', 'Automatic city detection, fallback behavior and the original simulated counter.', 'location'],
    ['Conversation timing', 'Adjust pauses and typing durations without changing message order.', 'timing']
  ]) {
    const card = el('section', 'card field-card'), text = el('div'); text.append(el('h3', '', title), el('p', 'muted', description)); card.append(text, button('Edit settings', () => editSettings(title, mode))); groups.append(card);
  }
  $('page-content').append(groups);
}
function editSettings(title, mode) {
  const original = { ...state.site.settings };
  openEditor(title, () => {
    if (mode === 'visibility') visibilityFields.forEach(([key, label]) => field(label, key, original[key], 'checkbox'));
    if (mode === 'location') {
      field('Detect visitor city automatically', 'enableGeolocation', original.enableGeolocation, 'checkbox', 'Uses the original external geolocation providers with a short timeout. The page does not wait for them.');
      field('Animate the simulated online counter', 'simulateOnlineCounter', original.simulateOnlineCounter, 'checkbox', 'This preserves the original randomized counter. It is not a measurement of real visitors.');
      const base = field('Base online count', 'onlineBase', original.onlineBase, 'number'); base.min = 0; base.max = 100000000; base.step = 1;
      const interval = field('Counter refresh interval (milliseconds)', 'onlineIntervalMs', original.onlineIntervalMs, 'number'); interval.min = 1000; interval.max = 60000; interval.step = 100;
    }
    if (mode === 'timing') timingFields.forEach(([key, label]) => { const input = field(`${label} (milliseconds)`, key, original[key], 'number'); input.min = 0; input.max = 30000; input.step = 100; });
  }, async values => {
    for (const [key, value] of Object.entries(values)) if (typeof value === 'number' && (!Number.isInteger(value) || value < 0 || value > (key === 'onlineBase' ? 100000000 : key === 'onlineIntervalMs' ? 60000 : 30000))) throw new Error('Use valid whole-number values within the displayed limits.');
    if (values.onlineIntervalMs !== undefined && values.onlineIntervalMs < 1000) throw new Error('The counter interval must be at least 1,000 ms.');
    await commit('site/settings', { ...original, ...values }, revision(original));
  });
}
function downloadJson(value, filename) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' }));
  const link = el('a'); link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 10000);
}
async function backup() {
  try {
    ensureOnline(); notify('Preparing your backup...');
    const [siteSnapshot, imageSnapshot] = await Promise.all([database.get(database.ref(db, 'site')), database.get(database.ref(db, 'images'))]);
    downloadJson({ exportedAt: new Date().toISOString(), schemaVersion: 1, site: siteSnapshot.val(), images: imageSnapshot.val() || {} }, `website-backup-${new Date().toISOString().slice(0, 10)}.json`);
    notify('Backup downloaded. It includes content and images, without administrator accounts.');
  } catch (error) { notify(errorText(error), true); }
}
async function initialize() {
  if (!confirm('Initialize the original website content and six profiles? This is only allowed when /site is empty.')) return;
  try {
    ensureOnline();
    if ((await database.get(database.ref(db, 'site'))).exists()) throw new Error('The website already has data. Initialization will not overwrite it.');
    const response = await fetch('./initial-content.json', { cache: 'no-store' }); if (!response.ok) throw new Error('Initial content file could not be loaded.');
    const initial = await response.json();
    await database.update(database.ref(db), { site: initial.site, images: initial.images });
    notify('Website initialized with the original profiles and content.');
  } catch (error) { notify(errorText(error), true); }
}
function backupPage() {
  const grid = el('div', 'backup-grid');
  const exportCard = el('section', 'card'); exportCard.append(el('h3', '', 'Export a complete backup'), el('p', '', 'Download profiles, images, messages, settings and links in one JSON file. Authentication accounts and administrator permissions are excluded.'), button('Download backup', () => void backup(), 'primary'));
  const restoreCard = el('section', 'card'); restoreCard.append(el('h3', '', 'Restore website content'), el('p', '', 'Replace public website data with an earlier backup. Export your current data first. Administrator access remains unchanged.'));
  const file = el('input'); file.type = 'file'; file.accept = '.json,application/json'; file.setAttribute('aria-label', 'Choose backup file');
  file.onchange = async () => {
    try {
      ensureOnline(); const selected = file.files[0]; if (!selected) return;
      if (selected.size > 25 * 1024 * 1024) throw new Error('Backup files must be smaller than 25 MB.');
      const data = JSON.parse(await selected.text());
      if (data.site?.schemaVersion !== 1 || !data.site.content || !data.site.settings || !data.site.buttons?.cta || !data.images || typeof data.images !== 'object') throw new Error('This is not a compatible website backup.');
      for (const [, p] of entries(data.site.profiles)) { validateProfile(p); if (!data.site.imageMeta?.[p.imageId] || !data.images[p.imageId]) throw new Error('A profile image is missing from this backup.'); }
      for (const [, c] of entries(data.site.conversations)) validateConversation(c);
      for (const [, asset] of entries(data.images)) if (!/^data:image\/(jpeg|png|webp);base64,/.test(asset.data || '') || asset.data.length > MAX_DATA_URL_LENGTH) throw new Error('The backup contains an invalid or oversized image.');
      if (!confirm('Replace all public website content and images with this backup? This affects current visitors immediately.')) return;
      await database.update(database.ref(db), { site: data.site, images: data.images }); state.imageCache.clear(); render(); notify('Backup restored.');
    } catch (error) { notify(errorText(error), true); } finally { file.value = ''; }
  };
  restoreCard.append(file); grid.append(exportCard, restoreCard); $('page-content').append(grid);
  const setup = el('section', 'card'); setup.style.marginTop = '20px'; setup.append(el('h3', '', 'Initialize an empty database'), el('p', 'muted', 'After configuring Firebase and administrator permissions, load the six original profiles, original photos and conversation variants.'), button('Initialize original content', () => void initialize())); $('page-content').append(setup);
  const identity = el('section', 'card'); identity.style.marginTop = '20px'; identity.append(el('h3', '', 'Your administrator account'), el('p', 'muted', `Signed in as ${state.user?.email || ''}`), el('p', 'inline-code', state.user?.uid || ''), el('p', 'small-note', 'Administrator UIDs are configured under /admins in the Firebase Console. Passwords and user accounts are managed in Firebase Authentication.')); $('page-content').append(identity);
}
function render() {
  if (!state.user) return;
  imageObserver?.disconnect();
  const hash = location.hash.slice(1); state.page = titles[hash] ? hash : 'dashboard';
  const [title, subtitle] = titles[state.page]; $('page-title').textContent = title; $('page-subtitle').textContent = subtitle;
  $('page-actions').replaceChildren(); $('page-content').replaceChildren();
  document.querySelectorAll('[data-page]').forEach(link => { link.classList.toggle('active', link.dataset.page === state.page); if (link.dataset.page === state.page) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current'); });
  if (!state.site?.content || state.site.schemaVersion !== 1) {
    $('page-content').append(note('Your database is empty or uses an unsupported schema. Use Backup & Setup to initialize the original website content.', true)); backupPage(); return;
  }
  ({ dashboard: overview, profiles: profilesPage, images: imagesPage, content: contentPage, conversations: conversationsPage, buttons: buttonsPage, settings: settingsPage, backup: backupPage })[state.page]();
}
function connectionBadge(connected) {
  state.connected = connected && navigator.onLine;
  $('connection-badge').textContent = state.connected ? 'Live synchronization' : 'Offline · saving paused';
  $('connection-badge').className = `badge ${state.connected ? 'good' : 'warn'}`;
}
async function boot() {
  $('login-button').disabled = true;
  try {
    const client = await import('./firebase-client.js'); ({ db, database } = client);
    const authClient = await client.authClient(); auth = authClient.auth; authApi = authClient.api;
    await authApi.setPersistence(auth, authApi.browserSessionPersistence);
    $('login-button').disabled = false; $('login-status').textContent = '';
    authApi.onAuthStateChanged(auth, async user => {
      const generation = ++authGeneration;
      siteUnsubscribe?.(); connectionUnsubscribe?.(); state.user = null; state.site = null; state.connected = false;
      $('admin-app').hidden = true; $('login-screen').hidden = false;
      if (!user) return;
      $('login-status').textContent = 'Verifying administrator access...';
      try {
        const permission = await database.get(database.ref(db, `admins/${user.uid}`));
        if (generation !== authGeneration) return;
        if (permission.val() !== true) { await authApi.signOut(auth); throw new Error('This account is not an administrator. Add its UID under /admins in the Firebase Console.'); }
        state.user = user; $('admin-email').textContent = user.email; $('login-screen').hidden = true; $('admin-app').hidden = false;
        connectionUnsubscribe = database.onValue(database.ref(db, '.info/connected'), snapshot => connectionBadge(snapshot.val() === true));
        siteUnsubscribe = database.onValue(database.ref(db, 'site'), snapshot => { state.site = snapshot.val(); render(); }, error => { notify(errorText(error), true); });
        $('login-status').textContent = '';
      } catch (error) { $('login-status').textContent = errorText(error); }
    });
  } catch (error) { $('login-status').textContent = errorText(error); }
}
$('login-form').onsubmit = async event => {
  event.preventDefault(); if (!auth || $('login-button').disabled) return;
  $('login-button').disabled = true; $('login-status').textContent = 'Signing in...';
  try { await authApi.signInWithEmailAndPassword(auth, $('email').value.trim(), $('password').value); $('password').value = ''; }
  catch (error) { $('login-status').textContent = errorText(error); }
  finally { $('login-button').disabled = false; }
};
$('editor-form').onsubmit = async event => {
  event.preventDefault(); if (state.busy || !$('editor-form').reportValidity()) return;
  $('editor-error').textContent = ''; state.busy = true; $('save-editor').disabled = true; $('save-editor').textContent = 'Saving...';
  try { await editorSubmit(valuesFromForm()); state.dirty = false; $('editor').close(); notify('Changes saved. The website updates automatically.'); }
  catch (error) { $('editor-error').textContent = errorText(error); }
  finally { state.busy = false; $('save-editor').disabled = false; $('save-editor').textContent = 'Save changes'; }
};
$('editor-form').addEventListener('input', () => { state.dirty = true; });
$('editor-form').addEventListener('change', () => { state.dirty = true; });
$('close-editor').onclick = closeEditor; $('cancel-editor').onclick = closeEditor;
$('editor').addEventListener('cancel', event => { event.preventDefault(); closeEditor(); });
$('logout').onclick = async () => {
  if (state.busy || (state.dirty && !confirm('Discard unsaved changes and sign out?'))) return;
  state.dirty = false; $('editor').close(); state.imageCache.clear(); await authApi.signOut(auth);
};
$('menu-toggle').onclick = () => { const open = $('sidebar').classList.toggle('open'); $('menu-toggle').setAttribute('aria-expanded', String(open)); };
window.addEventListener('hashchange', () => { $('sidebar').classList.remove('open'); $('menu-toggle').setAttribute('aria-expanded', 'false'); render(); });
window.addEventListener('beforeunload', event => { if (state.dirty || state.busy) { event.preventDefault(); event.returnValue = ''; } });
window.addEventListener('offline', () => connectionBadge(false));
window.addEventListener('online', async () => { if (db) connectionBadge((await database.get(database.ref(db, '.info/connected'))).val() === true); });
void boot();
