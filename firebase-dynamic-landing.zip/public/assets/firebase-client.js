import { initializeApp } from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js';
import * as database from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-database.js';
import { firebaseConfig, localEmulators } from '../firebase-config.js';

for (const key of ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'appId']) {
  if (!firebaseConfig[key] || firebaseConfig[key].includes('REPLACE_')) throw new Error('Firebase setup is incomplete. Fill in public/firebase-config.js using SETUP-BN.md in the project folder.');
}
const app = initializeApp(firebaseConfig);
export const db = database.getDatabase(app);
if (localEmulators && ['localhost', '127.0.0.1'].includes(location.hostname)) {
  database.connectDatabaseEmulator(db, localEmulators.host || '127.0.0.1', localEmulators.databasePort || 9000);
}
export { database };
export async function authClient() {
  const api = await import('https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js');
  const auth = api.getAuth(app);
  if (localEmulators && ['localhost', '127.0.0.1'].includes(location.hostname)) {
    api.connectAuthEmulator(auth, `http://${localEmulators.host || '127.0.0.1'}:${localEmulators.authPort || 9099}`, { disableWarnings: true });
  }
  return { auth, api };
}
