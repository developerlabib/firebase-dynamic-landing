export const SCHEMA_VERSION = 1;
export const MAX_IMAGE_BYTES = 120 * 1024;
export const MAX_DATA_URL_LENGTH = 170000;

export function entries(value) {
  return Object.entries(value || {}).filter(([key, item]) => !key.startsWith('__') && item && typeof item === 'object');
}

export function chooseProfile(profiles, previousId, random = Math.random) {
  const available = entries(profiles).filter(([, p]) => p.active === true);
  if (available.some(([id]) => id === previousId)) return previousId;
  return available.length ? available[Math.min(available.length - 1, Math.floor(random() * available.length))][0] : null;
}

export function chooseConversation(conversations, profile, previousId, random = Math.random) {
  const active = entries(conversations).filter(([, c]) => c.active === true);
  if (profile?.conversationId && active.some(([id]) => id === profile.conversationId)) return profile.conversationId;
  if (active.some(([id]) => id === previousId)) return previousId;
  return active.length ? active[Math.min(active.length - 1, Math.floor(random() * active.length))][0] : null;
}

export function resolveTokens(template, values) {
  return String(template ?? '').replace(/\{(city|name|age|brand|bio|extra|location|count)\}/g, (_, token) => String(values[token] ?? ''));
}

export function safeUrl(value, { allowEmpty = false } = {}) {
  const text = String(value || '').trim();
  if (!text && allowEmpty) return '';
  let url;
  try { url = new URL(text); } catch { throw new Error('Enter a complete URL starting with https:// or http://.'); }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) throw new Error('Only HTTP and HTTPS links without embedded credentials are allowed.');
  return url.href;
}

export function redirectUrl(target, search, preserveQuery) {
  const url = new URL(safeUrl(target));
  if (preserveQuery) new URLSearchParams(search).forEach((value, key) => url.searchParams.append(key, value));
  return url.href;
}

export function readSession(storage, key) {
  try { return JSON.parse(storage.getItem(key) || '{}') || {}; } catch { return {}; }
}
export function writeSession(storage, key, value) {
  try { storage.setItem(key, JSON.stringify(value)); } catch { /* Private browsing can disallow storage. Keep the in-memory assignment. */ }
}

export function validateProfile(profile) {
  if (!String(profile.name || '').trim() || profile.name.length > 100) throw new Error('Profile name is required (up to 100 characters).');
  if (!Number.isInteger(profile.age) || profile.age < 18 || profile.age > 120) throw new Error('Age must be a whole number between 18 and 120.');
  if (typeof profile.active !== 'boolean') throw new Error('Choose an active status.');
  if (!profile.imageId) throw new Error('Choose an image from Image Management first.');
  if (profile.url) safeUrl(profile.url);
  return profile;
}

export function validateConversation(conversation) {
  if (!conversation.title?.trim() || !conversation.initial?.trim() || !conversation.closing?.trim()) throw new Error('Title, opening message and closing message are required.');
  const options = (conversation.options || []).filter(x => String(x).trim());
  const followUps = (conversation.followUps || []).filter(x => String(x).trim());
  if (!options.length || options.length > 8 || !followUps.length || followUps.length > 12) throw new Error('Use 1-8 suggested replies and 1-12 follow-up messages.');
  if ([conversation.initial, conversation.closing, ...options, ...followUps].some(x => x.length > 2000)) throw new Error('Each message must be 2,000 characters or fewer.');
  return { ...conversation, options, followUps };
}

// One cancellable timer queue protects the opening -> reply -> follow-up -> closing order.
export class ConversationFlow {
  constructor({ wait, typing, message, options, timing, conversation, random = Math.random }) {
    Object.assign(this, { wait, typing, message, options, timing, conversation, random });
    this.generation = 0;
    this.state = 'idle';
  }
  cancel() { this.generation++; this.state = 'idle'; this.typing(false); this.options([]); }
  async pause(ms, generation) { await this.wait(ms); return generation === this.generation; }
  async start() {
    this.cancel();
    const generation = this.generation;
    this.state = 'opening';
    if (!await this.pause(this.timing().initialPauseMs, generation)) return;
    this.typing(true);
    if (!await this.pause(this.timing().initialTypingMs, generation)) return;
    this.typing(false);
    this.message('initial', this.conversation().initial);
    this.state = 'ready';
    this.options(this.conversation().options || []);
  }
  async reply(text) {
    if (this.state !== 'ready' || !(this.conversation().options || []).includes(text)) return false;
    const generation = this.generation;
    this.state = 'replying';
    this.options([]);
    this.message('reply', text);
    if (!await this.pause(this.timing().replyPauseMs, generation)) return false;
    this.typing(true);
    if (!await this.pause(this.timing().replyTypingMs, generation)) return false;
    this.typing(false);
    const followUps = this.conversation().followUps || [];
    this.message('followUp', followUps[Math.floor(this.random() * followUps.length)] || '');
    if (!await this.pause(this.timing().closingPauseMs, generation)) return false;
    this.typing(true);
    if (!await this.pause(this.timing().closingTypingMs, generation)) return false;
    this.typing(false);
    this.message('closing', this.conversation().closing);
    this.state = 'done';
    return true;
  }
}
