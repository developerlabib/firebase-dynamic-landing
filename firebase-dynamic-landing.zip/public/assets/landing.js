import { chooseProfile, chooseConversation, resolveTokens, redirectUrl, readSession, writeSession, ConversationFlow } from './core.js';

const $ = id => document.getElementById(id);
const searchMessage = 'Finding someone special in your area';
const sessionKey = 'dynamic-landing-session-v1';
let sessionStore;
try { sessionStore = window.sessionStorage; } catch { /* Use the in-memory assignment when browser storage is blocked. */ }
let assignment = readSession(sessionStore, sessionKey);
let site, activeProfileId, conversationId, imageId, imageUnsubscribe, database, db;
let detectedCity = '', onlineCount = 0, onlineTimer, geoStarted = false, siteUnsubscribe, connectedUnsubscribe;
let selectionVersion = 0, started = false, booted = false, imageReady = false, currentSearch = location.search;
const records = [];
const timers = new Map();
let loadTimeout;

function status(message, retry = false) {
  if ($('video-signup-dialog').open) $('video-signup-dialog').close();
  $('landing-app').hidden = true;
  $('landing-app').setAttribute('aria-hidden', 'true');
  $('load-state').hidden = false;
  $('load-message').textContent = message;
  $('retry-button').hidden = !retry;
  $('load-dot').hidden = retry;
  $('load-state').classList.toggle('is-error', retry);
  for (const id of ['load-kicker', 'load-caption', 'search-dots']) $(id).hidden = retry;
}
function connectionMessage() {
  const text = String(site?.content?.connectionText || '').trim();
  // Existing databases can keep their original status text; no data re-import is needed.
  return !text || /^(?:loading|connecting)[.\s…]*$/i.test(text) ? searchMessage : text;
}
function reveal() {
  clearTimeout(loadTimeout);
  $('load-state').hidden = true;
  $('landing-app').hidden = false;
  $('landing-app').setAttribute('aria-hidden', 'false');
}
function values() {
  const p = site?.profiles?.[activeProfileId] || {};
  return { city: p.location || detectedCity || site?.content?.fallbackCity, location: p.location || detectedCity || site?.content?.fallbackCity,
    name: p.name, age: p.age, bio: p.bio, extra: p.extra, brand: site?.content?.brandTitle,
    count: Math.max(0, onlineCount).toLocaleString() };
}
function tokens(text) { return resolveTokens(text, values()); }
function richText(element, template) {
  element.replaceChildren();
  // Preserve the original bold brand mention while treating all admin text as text, never executable HTML.
  String(template || '').split(/(\{brand\})/g).forEach(part => {
    if (part === '{brand}') { const strong = document.createElement('b'); strong.textContent = values().brand; element.append(strong); }
    else element.append(document.createTextNode(tokens(part)));
  });
}
function updateMessages() {
  records.forEach(record => richText(record.bubble, record.template));
  if (flow.state === 'ready') renderOptions(site.conversations[conversationId]?.options || []);
}
function renderOptions(options) {
  $('suggested-box').replaceChildren();
  if (!site?.settings?.showSuggested || !site.settings.showChat) return;
  options.forEach(text => {
    const button = document.createElement('button');
    button.className = 'suggest-chip';
    button.type = 'button';
    button.textContent = tokens(text) + site.content.suggestedSuffix;
    button.onclick = () => { void flow.reply(text); };
    $('suggested-box').append(button);
  });
}
function append(kind, template) {
  const row = document.createElement('div');
  row.className = `message ${kind === 'reply' ? 'outgoing' : 'incoming'}`;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  richText(bubble, template);
  const timestamp = document.createElement('div');
  timestamp.className = 'timestamp';
  const date = new Date();
  timestamp.textContent = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  row.append(bubble, timestamp);
  $('chat-box').append(row);
  records.push({ kind, template, bubble });
  $('chat-box').scrollTop = $('chat-box').scrollHeight;
}
const flow = new ConversationFlow({
  wait: ms => new Promise(resolve => { const timer = setTimeout(() => { timers.delete(timer); resolve(); }, ms); timers.set(timer, resolve); }),
  typing: visible => { $('typing').style.display = visible && site?.settings?.showChat ? 'flex' : 'none'; },
  message: append,
  options: renderOptions,
  timing: () => site.settings,
  conversation: () => site.conversations[conversationId]
});
function resetConversation() {
  flow.cancel();
  for (const [timer, resolve] of timers) { clearTimeout(timer); resolve(); }
  timers.clear();
  records.length = 0;
  $('chat-box').querySelectorAll('.message').forEach(node => node.remove());
  started = false;
}
function bindContent() {
  const c = site.content, s = site.settings, p = site.profiles[activeProfileId], b = site.buttons.cta;
  document.title = c.pageTitle;
  document.querySelector('meta[name="description"]').content = c.metaDescription;
  const bindings = { 'brand-title': c.brandTitle, 'location-prefix': c.locationPrefix,
    'date-label': c.dateLabel, 'age-label': c.ageLabel, 'age-emphasis': c.ageEmphasis, 'profile-name': p.name,
    'profile-age': p.age, 'user-city': values().city, 'online-text': tokens(c.onlineTemplate),
    'video-age-label': c.ageLabel, 'video-age-emphasis': c.ageEmphasis,
    'cta-button': p.buttonLabel || b.label };
  Object.entries(bindings).forEach(([id, text]) => { $(id).textContent = text; });
  const videoLabel = c.chatPill?.trim() && !/^chat$/i.test(c.chatPill.trim()) ? c.chatPill.trim() : 'Start a video call';
  $('video-call-button').setAttribute('aria-label', videoLabel);
  $('video-call-button').title = videoLabel;
  $('video-signup-description').textContent = `Sign up on ${c.brandTitle} to continue.`;
  $('profile-img').alt = tokens(c.imageAlt);
  const sections = { 'section-brand': s.showBrand, 'section-profile': s.showProfile, 'online-counter': s.showOnlineCounter,
    'chat-box': s.showChat, 'suggested-box': s.showChat && s.showSuggested, 'typing-section': s.showChat,
    'section-cta': s.showCta };
  Object.entries(sections).forEach(([id, shown]) => { $(id).hidden = !shown; });
  document.querySelector('.date-divider').hidden = !s.showDate;
  document.querySelector('.age-checkbox').hidden = !s.showAgeCheck;
  document.querySelector('.verified-badge').hidden = !s.showVerified;
  document.querySelector('.avatar-status').hidden = !s.showAvatarStatus;
  $('cta-button').disabled = !b.enabled || (s.showAgeCheck && !$('age-check').checked);
  $('video-call-button').disabled = !b.enabled;
  $('video-signup-button').disabled = $('cta-button').disabled;
  $('video-age-check').checked = $('age-check').checked;
  $('video-age-row').hidden = !s.showAgeCheck;
  updateMessages();
}
function updateCounter() {
  if (site) $('online-text').textContent = tokens(site.content.onlineTemplate);
}
function setCounter(previous) {
  if (!previous || previous.onlineBase !== site.settings.onlineBase) onlineCount = site.settings.onlineBase;
  if (previous?.onlineIntervalMs === site.settings.onlineIntervalMs && previous?.simulateOnlineCounter === site.settings.simulateOnlineCounter && (onlineTimer || !site.settings.simulateOnlineCounter)) return;
  clearInterval(onlineTimer);
  onlineTimer = null;
  if (site.settings.simulateOnlineCounter) onlineTimer = setInterval(() => {
    onlineCount = Math.max(0, onlineCount + (Math.random() > 0.5 ? 1 : -1) * (Math.floor(Math.random() * 24) + 2));
    updateCounter();
  }, Math.max(1000, site.settings.onlineIntervalMs));
}
async function locate() {
  if (geoStarted || !site.settings.enableGeolocation) return;
  geoStarted = true;
  // Location is supplementary and never blocks initial rendering or the first message.
  for (const [url, property] of [['https://freeipapi.com/api/json', 'cityName'], ['https://ipapi.co/json/', 'city']]) {
    if (!site.settings.enableGeolocation) break;
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(2500), referrerPolicy: 'no-referrer' });
      if (!response.ok) continue;
      const result = await response.json();
      if (!site.settings.enableGeolocation) return;
      if (typeof result[property] === 'string' && result[property].trim()) { detectedCity = result[property].slice(0, 100); break; }
    } catch { /* Keep the editable fallback when geolocation is unavailable. */ }
  }
  if (site?.profiles?.[activeProfileId]) bindContent();
}
function subscribeImage(nextId) {
  imageUnsubscribe?.();
  imageReady = false;
  imageId = nextId;
  const version = ++selectionVersion;
  imageUnsubscribe = database.onValue(database.ref(db, `images/${nextId}`), async snapshot => {
    if (version !== selectionVersion) return;
    const data = snapshot.val()?.data;
    const src = /^data:image\/(jpeg|png|webp);base64,/.test(data || '') ? data : './assets/avatar-placeholder.svg';
    const probe = new Image();
    probe.src = src;
    try { await probe.decode(); } catch { if (version === selectionVersion) probe.src = './assets/avatar-placeholder.svg'; }
    if (version !== selectionVersion) return;
    $('profile-img').src = probe.src;
    imageReady = true;
    reveal();
    if (!started && site.settings.showChat) { started = true; void flow.start(); }
  }, () => {
    if (version !== selectionVersion) return;
    $('profile-img').src = './assets/avatar-placeholder.svg';
    imageReady = true;
    reveal();
    if (!started && site.settings.showChat) { started = true; void flow.start(); }
  });
}
function receiveSite(snapshot) {
  const next = snapshot.val();
  if (next?.schemaVersion !== 1 || !next.content || !next.settings || !next.buttons?.cta) {
    resetConversation();
    imageUnsubscribe?.(); imageId = null; imageReady = false; selectionVersion++;
    clearInterval(onlineTimer); onlineTimer = null; clearTimeout(loadTimeout);
    site = null; activeProfileId = null;
    status('This website has not been initialized. Please contact the administrator.', true);
    return;
  }
  const previous = site;
  site = next;
  if (!site.settings.enableGeolocation) { detectedCity = ''; geoStarted = false; }
  const selected = chooseProfile(site.profiles, activeProfileId || assignment.profileId);
  if (!selected) {
    resetConversation(); imageUnsubscribe?.(); imageId = null; selectionVersion++;
    clearInterval(onlineTimer); onlineTimer = null; clearTimeout(loadTimeout);
    status(site.content.unavailableText, true); $('load-dot').hidden = true;
    activeProfileId = null;
    return;
  }
  const nextConversation = chooseConversation(site.conversations, site.profiles[selected], conversationId || assignment.conversationId);
  if (!nextConversation && site.settings.showChat) {
    resetConversation(); imageUnsubscribe?.(); imageId = null; selectionVersion++;
    clearInterval(onlineTimer); onlineTimer = null; clearTimeout(loadTimeout);
    status(site.content.unavailableText, true); return;
  }
  const switched = activeProfileId !== selected || conversationId !== nextConversation;
  if (switched || (previous?.settings.showChat && !site.settings.showChat)) resetConversation();
  activeProfileId = selected; conversationId = nextConversation;
  assignment = { profileId: selected, conversationId: nextConversation };
  writeSession(sessionStore, sessionKey, assignment);
  setCounter(previous?.settings);
  bindContent();
  const nextImage = site.profiles[selected].imageId;
  if (imageId !== nextImage || switched || !booted) {
    status(connectionMessage());
    subscribeImage(nextImage);
  } else if (imageReady) {
    reveal();
    if (!started && site.settings.showChat) { started = true; void flow.start(); }
  }
  booted = true;
  void locate();
}
async function boot() {
  status(searchMessage);
  loadTimeout = setTimeout(() => status('The website is taking longer than expected. Check your connection and try again.', true), 15000);
  try {
    const client = await import('./firebase-client.js');
    ({ database, db } = client);
    siteUnsubscribe = database.onValue(database.ref(db, 'site'), receiveSite, error => {
      resetConversation(); imageUnsubscribe?.(); selectionVersion++; clearInterval(onlineTimer); onlineTimer = null; clearTimeout(loadTimeout);
      status(error.code === 'PERMISSION_DENIED' ? 'Website access is unavailable. Please contact the administrator.' : 'Unable to load the website. Please try again.', true);
    });
    connectedUnsubscribe = database.onValue(database.ref(db, '.info/connected'), snapshot => {
      document.documentElement.dataset.connected = snapshot.val() ? 'true' : 'false';
    });
  } catch (error) { clearTimeout(loadTimeout); status(error.message || 'Unable to load the website.', true); }
}
$('retry-button').onclick = () => location.reload();
for (const id of ['age-check', 'video-age-check']) $(id).addEventListener('change', () => {
  $('age-check').checked = $(id).checked;
  if (site && activeProfileId) bindContent();
});
function goToSignup() {
  if (!site || $('cta-button').disabled) return;
  const b = site.buttons.cta, p = site.profiles[activeProfileId];
  try { location.assign(redirectUrl(p.url || b.url, currentSearch, b.preserveQuery)); }
  catch { status('The destination link is unavailable. Please contact the administrator.', true); }
}
$('cta-button').addEventListener('click', goToSignup);
$('video-signup-button').addEventListener('click', goToSignup);
$('video-call-button').addEventListener('click', () => {
  if (!site || $('video-call-button').disabled) return;
  $('video-signup-dialog').showModal();
});
for (const id of ['video-signup-close', 'video-signup-cancel']) $(id).addEventListener('click', () => $('video-signup-dialog').close());
window.addEventListener('pagehide', () => {
  siteUnsubscribe?.(); connectedUnsubscribe?.(); imageUnsubscribe?.(); clearInterval(onlineTimer); resetConversation();
});
window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
void boot();
