import { MAX_IMAGE_BYTES, MAX_DATA_URL_LENGTH } from './core.js';

export async function compressImage(file) {
  if (!file || !/^image\/(jpeg|png|webp|gif|avif|bmp)$/i.test(file.type)) throw new Error('Choose a JPG, JPEG, PNG, WebP, GIF, AVIF or BMP image.');
  if (file.size > 20 * 1024 * 1024) throw new Error('Choose an image smaller than 20 MB.');
  let bitmap;
  try { bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch { throw new Error('This browser cannot decode the image. Convert it to JPG or PNG and try again.'); }
  try {
    if (!bitmap.width || !bitmap.height) throw new Error('The image is empty.');
    let scale = Math.min(1, 640 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    for (let attempt = 0; attempt < 7; attempt++) {
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      const context = canvas.getContext('2d');
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const data = canvas.toDataURL('image/webp', Math.max(.5, .82 - attempt * .05));
      const mime = data.substring(5, data.indexOf(';'));
      const bytes = Math.floor((data.length - data.indexOf(',') - 1) * 3 / 4);
      if (bytes <= MAX_IMAGE_BYTES && data.length <= MAX_DATA_URL_LENGTH) return { data, mime, bytes, width: canvas.width, height: canvas.height };
      scale *= .78;
    }
    throw new Error('This image is too complex to compress. Choose a smaller image.');
  } finally { bitmap.close(); }
}
