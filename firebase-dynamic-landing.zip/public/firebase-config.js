// New project: replace these five values with your own Firebase app details.
// Copy databaseURL from Realtime Database. See SETUP-BN.md in the project folder.
// These are public app identifiers. Never put passwords or private keys here.
export const firebaseConfig = {
  apiKey: "REPLACE_API_KEY",
  authDomain: "REPLACE_AUTH_DOMAIN",
  databaseURL: "REPLACE_DATABASE_URL",
  projectId: "REPLACE_PROJECT_ID",
  appId: "REPLACE_APP_ID"
};

// Keep null for your live Firebase website.
export const localEmulators = null;
